-- created by cye
DROP TABLE relationship_eav;
DROP TABLE relationship_ea;
DROP TABLE relationship;
DROP TABLE relationship_def;
DROP TABLE domains;
DROP TABLE hierarchy_node_eav;
DROP TABLE hierarchy_node_ea;
DROP TABLE hierarchy_node;
DROP TABLE hierarchy_def;
