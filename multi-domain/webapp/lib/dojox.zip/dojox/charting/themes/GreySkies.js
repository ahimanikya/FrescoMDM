/*
	Copyright (c) 2004-2008, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["dojox.charting.themes.GreySkies"]){
dojo._hasResource["dojox.charting.themes.GreySkies"]=true;
dojo.provide("dojox.charting.themes.GreySkies");
dojo.require("dojox.charting.Theme");
(function(){
var _1=dojox.charting;
_1.themes.GreySkies=new _1.Theme(_1.Theme._def);
})();
}
