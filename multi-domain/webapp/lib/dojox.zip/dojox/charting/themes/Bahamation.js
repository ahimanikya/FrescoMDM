/*
	Copyright (c) 2004-2008, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["dojox.charting.themes.Bahamation"]){
dojo._hasResource["dojox.charting.themes.Bahamation"]=true;
dojo.provide("dojox.charting.themes.Bahamation");
dojo.require("dojox.charting.Theme");
(function(){
var _1=dojox.charting;
_1.themes.Bahamation=new _1.Theme({colors:["#3f9998","#3fc0c3","#70c058","#ef446f","#c663a6"]});
})();
}
