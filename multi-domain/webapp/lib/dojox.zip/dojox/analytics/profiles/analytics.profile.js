/*
	Copyright (c) 2004-2008, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


dependencies={layers:[{name:"../dojox/analytics.js",dependencies:["dojox.analytics","dojox.analytics.plugins.dojo","dojox.analytics.plugins.window","dojox.analytics.plugins.consoleMessages","dojox.analytics.plugins.mouseOver","dojox.analytics.plugins.mouseClick","dojox.analytics.plugins.idle"]}],prefixes:[["dojox","../dojox"],["dijit","../dijit"]]};
