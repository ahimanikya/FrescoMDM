/*
 * PersonFields.java
 *
 * Created on November 12, 2007, 11:20 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.sun.mdm.index.edm.presentation.valueobjects;

public class PersonFields {

    private String PersonCatCode;
    private String LastName;
    private String FirstName;
    private String MiddleName;
    private String Suffix;
    private String Title;    
    private String DOB;    
    private String Death;    
    private String Gender;    
    private String MStatus;    
    private String SSN;    
    private String RACE;    
    private String Ethnic;    
    private String Religion;    
    private String  Language;
    private String  SpouseName;
    private String  MotherName;
    private String  MotherMN;
    private String  FatherName;
    private String  Maiden;
    private String  PobCity;
    private String  PobState;
    private String  PobCountry;
    private String  VIPFlag;
    private String  VetStatus;
    /** Creates a new instance of PersonFields */
    public PersonFields() {
    }
    
}
