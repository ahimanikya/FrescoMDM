/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.sun.mdm.index.mdm.presentation;

import java.util.ArrayList;
import com.sun.mdm.index.edm.services.configuration.ScreenObject;
import java.util.Arrays;
import java.util.HashMap;
import javax.el.ELResolver;
import javax.faces.context.FacesContext;
import javax.el.ValueExpression;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Anil Kumar Veeramalli
 */

public class HeaderBean {

    /** Creates a new instance of HeaderBean */
    public HeaderBean() {
    }
    private String dispalyTitle;
    private String screenID;
    private ArrayList<HearderVO> records; 
    private String screenTitle;
    private HashMap valueMap;
     

    public String getDispalyTitle() {
        return dispalyTitle;
    }

    public void setDispalyTitle(String dispalyTitle) {
        this.dispalyTitle = dispalyTitle;
    }

    public String getScreenID() {
        return screenID;
    }

    public void setScreenID(String screenID) {
        this.screenID = screenID;
    }

    public ArrayList<HearderVO> getRecords() {
        return records;
    }

    public void setRecords(ScreenObject screenObjeects[]) {
         ArrayList<HearderVO> screenObj= new ArrayList<HearderVO>();
        for (ScreenObject obj:screenObjeects){
            HearderVO hearderVO= new HearderVO();
            hearderVO.setDisplayTitle(obj.getDisplayTitle());
            hearderVO.setScreenId(obj.getID().toString());    
            screenObj.add(hearderVO);
        }         
        this.records = screenObj;
    }

    public String getScreenTitle() {
        return screenTitle;
    }

    public void setScreenTitle(String screenTitle) {
        this.screenTitle = screenTitle;
    }

    public HashMap getValueMap() {                
     return valueMap;
        
    }

    public void setValueMap(HashMap valueMap) {
        System.out.println("setting parameters....");
       
        HttpSession session =(HttpSession)  FacesContext.getCurrentInstance().getExternalContext().getSession(false);        
        session.setAttribute("HeaderBean", valueMap);
        this.valueMap = valueMap;
    }
    
    private Object getValue(FacesContext context, String expr) {
        return getValue(context, expr, expr.getClass());
    }

    protected Object getValue(FacesContext context, String expr, Class c) {
        
        ValueExpression ve = context.getApplication().getExpressionFactory().createValueExpression(
                context.getELContext(), expr, c);

        if (ve != null) {
            return ve.getValue(context.getELContext());
        }

        return null;
    }

/** Evaluate and return the given value binding expression
* @param context The FacesContext for this web app
* @param expr The value binding expression to be evaluated, such as "Sum is #{foo.sum}"
* @return The value of the expression
*/
public void setValue(FacesContext context, String expr, HashMap value) {
ValueExpression ve = context.getApplication().getExpressionFactory().createValueExpression(
context.getELContext(), expr, value.getClass());

if (ve != null) {
ve.setValue(context.getELContext(), value);
}
}

/** Find the named JSF managed bean
* @param context The FacesContext for this web app
* @param expr The name of the managed bean to be found, such as "SessionBean1"
* @return The managed bean
*/
    protected Object getBean(FacesContext context, String name) {
        ELResolver resolver = context.getApplication().getELResolver();

        return resolver.getValue(context.getELContext(), null, name);
         
    }
    
   

}
